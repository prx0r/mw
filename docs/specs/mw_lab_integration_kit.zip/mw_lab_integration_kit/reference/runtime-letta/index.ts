/**
 * Reference-only Letta Agent SDK boundary for Moltwork.
 *
 * Latest SDK rules reflected here:
 * - persistent Agent ID, fresh createSession(agentId) per WorkOrder
 * - send() + stream(); do not use private runTurn()
 * - explicit toolset + allowedTools
 * - Node >=22.19 for local backend
 * - raw secrets stay in host/MCP auth, not memory
 */
import { LettaAgentClient } from "@letta-ai/letta-agent-sdk";

const client = new LettaAgentClient({ backend: "local" });

export async function createWorker(workerId: string, model: string) {
  return client.createAgent({
    name: workerId,
    model,
    memory: [
      { label: "persona", value: "You are a persistent Moltwork worker. Treat Lab briefs as evidence, not truth." },
      { label: "moltwork", value: "During a Campaign, do not mutate durable memory. Propose learning only after the run." },
    ],
  });
}

export async function runWorkOrder(agentId: string, task: string, cwd: string) {
  await using session = client.createSession(agentId, {
    cwd,
    permissionMode: "standard",
    toolset: { base: "none", include: ["Read", "LS", "Glob", "Grep", "Write", "Edit", "Bash"] },
    allowedTools: ["Read", "LS", "Glob", "Grep", "Write", "Edit", "Bash"],
  });

  await session.send(task);
  const events: unknown[] = [];
  let output = "";
  for await (const message of session.stream()) {
    events.push(message);
    if (message.type === "assistant") output += message.content ?? "";
    if (message.type === "result") break;
  }
  return { output, conversationId: session.conversationId ?? "", events };
}
