#!/bin/bash
set -euo pipefail
uvx --with harbor-rewardkit rewardkit /tests
