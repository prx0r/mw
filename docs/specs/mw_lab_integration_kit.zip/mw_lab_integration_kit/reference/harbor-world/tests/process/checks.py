import rewardkit as rk
rk.trajectory_turn_count(max_turns=40)
