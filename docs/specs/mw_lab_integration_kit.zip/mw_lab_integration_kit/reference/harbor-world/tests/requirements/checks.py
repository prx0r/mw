import rewardkit as rk
rk.file_exists("submission.md", weight=3.0)
rk.file_contains("submission.md", "Architecture")
rk.file_contains("submission.md", "Evidence")
