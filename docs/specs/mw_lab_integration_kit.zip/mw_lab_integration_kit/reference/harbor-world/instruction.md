# Technical submission
Create a concrete technical submission in `/app/submission.md` with requirements, architecture, implementation evidence, and test evidence.
