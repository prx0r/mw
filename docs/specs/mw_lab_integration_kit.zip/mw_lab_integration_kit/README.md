# Moltwork Lab Integration Kit — checkpoint 1

A deliberately small, tested reference kit for connecting the current Moltwork architecture to **real upstream boundaries** without waiting for expensive Letta runs.

## What this solves now

- **Fast inner loop:** `FakeWorkerRuntime` has the same execution contract as `runtime-letta`; use it for orchestration tests in milliseconds.
- **Harbor bridge mode:** wrap a completed Letta/Git workspace in a real Harbor task using a `nop` agent, separate verifier, explicit artifact collection, and Reward Kit. This gives regradable Harbor evidence immediately.
- **Regrade model:** parse original + regraded trials without mutating the original run.
- **HydraDB boundary:** project the binding/evaluations over the documented HTTP/OpenCypher endpoint rather than building another graph DB.
- **WorkerKit binding:** one content-addressed statement binds Campaign + WorkerVersion + Letta conversation + workspace digest + Harbor lock/result.
- **Oracle continuity:** keeps H0-H4; adds structured `ExecutionStep`/`HumanDependency` helpers instead of inventing another autonomy taxonomy.
- **Credential hygiene:** `CredentialRef` stores references only; raw API keys must remain in Arcade/Composio/Infisical/Vault/host secret channels, never Git/Letta/Hydra/ATIF.

## Why bridge mode first

Native Letta-in-Harbor is not the first checkpoint. A persistent Letta worker and Harbor's ephemeral container have a real filesystem/tool-ownership integration problem. Solving that before gathering data slows you down.

Bridge mode is:

```text
Oracle opportunity
    ↓
Campaign Git worktree
    ↓
real Letta WorkerRun
    ↓
finished workspace commit
    ↓
Harbor artifact-evaluation task
    ↓
Harbor nop + separate RewardKit verifier
    ↓
regradable Harbor trial
    ↓
WorkerKit RunBinding
    ↓
HydraDB projection
```

Later replace the bridge with a native Harbor custom/external agent when the operational value is proven. The RunBinding schema does not need to change.

## Fast test

```bash
cd mw_lab_integration_kit
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python examples/fast_checkpoint.py
```

## Real Harbor smoke

Install upstream Harbor normally:

```bash
uv tool install harbor
```

Generate a task around a workspace already produced by Letta:

```bash
PYTHONPATH=src python examples/build_real_harbor_task.py
harbor run -p ./generated-harbor-task -a nop --env docker
```

The generated task uses:

- `artifacts = ["/app/workspace"]`
- `[verifier] environment_mode = "separate"`
- `uvx --with harbor-rewardkit rewardkit /tests`

Those are the important conditions for later regrade.

Then evolve the assessor by copying/editing `tests/` and run:

```bash
harbor job regrade jobs/<source-job> -p ./generated-harbor-task-v1 -e docker
```

## Real Letta smoke

Keep the Agent SDK in Node. The current Python side should call `services/runtime-letta`, not reinvent the SDK.

```python
from mw_labkit.runtime import LettaRuntimeClient

r = LettaRuntimeClient("http://127.0.0.1:3000")
r.ensure_worker("researcher-v1", model="your-model")
result = r.execute("researcher-v1", "Build the artifact", "/path/to/campaign/worktree")
print(result.conversation_id)
```

See `reference/runtime-letta/index.ts` for the current Agent SDK pattern: persistent agent, fresh `createSession`, explicit toolset, `send()` + `stream()`.

## HydraDB

```python
from mw_labkit.hydra import HydraHTTPClient

g = HydraHTTPClient(
    base_url="http://127.0.0.1:8443",
    token="...",
    namespace="default",
)
g.project_run_binding(binding)
g.project_evaluation(evaluation)
```

This intentionally uses the documented public HTTP/OpenCypher boundary. If you prefer the Neo4j driver, swap the sink; the domain records do not change.

## The first 3 experiments

1. **Evaluator evolution for free:** one real Letta run; Assessor v0/v1/v2 via Harbor regrade. Compare against eventual external outcome.
2. **Process treatment:** same worker/world/assessor, one candidate Process change vs control. Do not mutate worker memory during the active campaign.
3. **Second live Campaign:** generate Hydra/Lab brief from Campaign 1 evidence and compare whether starting from prior evidence improves quality/cost.

Only after those work should GEPA, Trace2Skill, dreaming, or OpenEvolve enter as treatments.

## Files to copy/model into `mw`

- `src/mw_labkit/runtime.py` → shape of the slow-worker boundary
- `src/mw_labkit/rewardkit_scaffold.py` → replace fake Harbor verifier generation
- `src/mw_labkit/harbor.py` → Harbor CLI + trial parser + fast mock
- `src/mw_labkit/hydra.py` → actual HydraDB transport boundary
- `src/mw_labkit/records.py` → minimal cross-system evidence binding
- `src/mw_labkit/oracle.py` → structured human-step model while preserving H0-H4
- `PATCHING_MW.md` → direct current-branch changes

## Explicit non-goals

This kit does not implement:
- agent evolution;
- memory algorithms;
- Harbor internals;
- Reward Kit internals;
- HydraDB storage;
- secret storage;
- marketplace logic;
- a generic 17-step autonomous orchestrator.

Those are precisely the things Moltwork should avoid owning right now.
