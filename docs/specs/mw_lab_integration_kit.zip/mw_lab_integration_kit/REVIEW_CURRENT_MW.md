# Review of current `mw/ethonline-2026` checkpoint

Reviewed head: `a6229fe7e3f559aa1df5ab3b1a5186040c5c472c` (2026-08-31 02:43 UTC).

## What is genuinely ready to keep

- WorkerKit's evidence kernel is already the strongest part of the repo: event-chain integrity, content-addressed artifacts, budget/EV rules and receipt binding have dedicated tamper/invariant tests in earlier commits.
- The frozen architecture is directionally correct: Letta owns persistent cognition, Git owns versions, Harbor owns executable evaluation, Hydra is derived knowledge, CGE is experiment semantics.
- `services/runtime-letta/` is the correct boundary: Python should not implement a second Letta SDK.
- Campaign, WorkerVersion, AssessorVersion and WorldVersion are useful reference objects.
- Existing H0-H4 remains the canonical human-involvement axis. Do not add another agentability taxonomy.

## What is still a sketch, not production

- `harbor_adapter.py` reimplements task/verifier concepts and should be replaced with real Harbor task files + Reward Kit.
- `flywheel/evaluator.py` contains regex proxies for novelty/feasibility. These will Goodhart immediately and should never feed worker learning as ground truth.
- `full_loop.py` hardcodes placeholder scientist conclusions and promotion behavior; archive it until explicit transitions work on live Campaigns.
- `hydra_projectors.py` is still SQLite despite its name. Keep a SQLite test projection if useful, but production should use HydraDB's HTTP/Bolt boundary.
- `opportunities/schema.py` contains useful human-dependency/evidence fields but currently omits several from round-trip serialization; fix before Oracle relies on them.
- `venues/base.py` has an overlapping Opportunity record; converge on the canonical opportunity schema.

## One likely Letta cleanup

The current runtime service should be checked against the newest Agent SDK options before another long run. Current docs use `permissionMode: "standard"` / current supported modes, explicit `toolset`, and `send()` + `stream()` on the public session surface. The reference TypeScript file in this kit models that boundary. Local Agent SDK execution requires Node >=22.19.

## Critical implementation shortcut discovered

Do not block checkpoint 1 on making a persistent Letta agent run *inside* Harbor's ephemeral environment.

Use **bridge mode**:

1. Letta produces the real Campaign Git workspace.
2. Snapshot that workspace into a Harbor task image.
3. Harbor runs `nop`; separate Reward Kit verifier evaluates `/app/workspace`.
4. WorkerKit binds the real Letta run to the Harbor lock/result digests.
5. Evolve assessors with `harbor job regrade` without another Letta turn.

This gives Moltwork the most valuable Harbor primitive — immutable cheap regrade — immediately. Later, if native Letta↔Harbor execution has enough value, implement it as a separate integration experiment rather than making it prerequisite infrastructure.

## First live checkpoint

A successful checkpoint is one real submission Campaign with:

- persistent Letta worker + fresh conversation;
- Git workspace digest/commit;
- WorkerKit evidence chain;
- Harbor separate-mode artifact evaluation;
- at least two AssessorVersions from the same WorkerRun via regrade;
- HydraDB projection linking Run → WorkerVersion → HarborTrial → Evaluations;
- eventual external Outcome attached later.

Repeat on Campaign 2 before introducing GEPA/Trace2Skill/OpenEvolve.
