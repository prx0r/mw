# How to apply this to the current `mw/ethonline-2026` branch

## Keep
- `core/` WorkerKit evidence kernel and tamper invariants.
- `campaign.py`, but keep it a record/state object rather than a magical orchestrator.
- `services/runtime-letta/` as the only Letta Agent SDK boundary.
- taxonomy H0-H4, Packs, canonical Opportunity, WorkVenue interface.
- Git WorkerVersion / AssessorVersion / WorldVersion refs.

## Replace / demote
1. **`harbor_adapter.py`**: replace its home-grown Harbor/RewardKit classes with `mw_labkit.rewardkit_scaffold` + `mw_labkit.harbor.HarborCLI` patterns. Never implement Reward Kit scoring yourself.
2. **`flywheel/evaluator.py`**: remove regex "novelty" / "feasibility" scores from production. Keep only deterministic facts that are genuinely deterministic; subjective criteria belong in Reward Kit judges.
3. **`full_loop.py`**: archive as architecture reference. Run explicit transitions until real campaigns prove the automation points.
4. **`hydra_projectors.py` SQLite graph**: keep only as optional test cache. Add a HydraDB sink behind the documented HTTP/Bolt boundary.
5. **duplicate `Opportunity` in `venues/base.py`**: import canonical `opportunities.schema.Opportunity` instead.
6. Fix canonical Opportunity round-trip so `eligibility`, `venue_policy`, `human_dependencies`, `source_evidence`, and `market_signals` serialize/deserialize.

## First production bridge
Do **not** block on native Letta-inside-Harbor execution.

1. Letta runs in the Campaign Git worktree using `services/runtime-letta`.
2. Snapshot the finished Git workspace into a Harbor artifact-evaluation task.
3. Run Harbor with `nop`; the trial is evaluation evidence only.
4. Bind the Harbor trial digest to the real Letta WorkerRun in WorkerKit.
5. Regrade the Harbor trial as assessors evolve.
6. Store the Letta trajectory separately; later native Harbor-Letta integration can add ATIF in the same trial.

This gives you Harbor regrade immediately without solving remote filesystem/tool ownership first.

## Why bridge mode is honest
The Harbor trial's `agent` is `nop`. Do not claim Harbor executed Letta. Moltwork's RunBinding explicitly identifies the external Letta worker and the Harbor trial as an evaluation wrapper. This preserves provenance and still unlocks regrade.
