import json
import tempfile
import unittest
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from mw_labkit.campaign import FastCampaignHarness
from mw_labkit.runtime import FakeWorkerRuntime, LettaRuntimeClient
from mw_labkit.records import WorkerVersionRef, CredentialRef
from mw_labkit.harbor import HarborJobParser, HarborCLI
from mw_labkit.hydra import MemoryGraphSink, HydraHTTPClient
from mw_labkit.oracle import HumanDependency, ExecutionStep, derive_autonomy_level, AutomationCandidate, choose_automation
from mw_labkit.rewardkit_scaffold import AssessorSpec, build_artifact_evaluation_task


class LabKitTests(unittest.TestCase):
    def test_fast_campaign_and_regrade(self):
        with tempfile.TemporaryDirectory() as td:
            h = FastCampaignHarness(td, FakeWorkerRuntime())
            worker = WorkerVersionRef("researcher", "v0", model="fake/model")
            binding, e0, job = h.execute_and_grade("opp-1", "build it", worker)
            e1 = h.regrade(binding, job)
            self.assertEqual(binding.run_id, e1.run_id)
            self.assertIsNotNone(e0.reward)
            self.assertIsNotNone(e1.reward)
            regraded = HarborJobParser.trials(Path(td) / "mock-harbor")
            self.assertGreaterEqual(len(regraded), 2)
            self.assertTrue(any(t.source_trial for t in regraded))

    def test_regrade_does_not_mutate_original_result(self):
        with tempfile.TemporaryDirectory() as td:
            h = FastCampaignHarness(td, FakeWorkerRuntime())
            worker = WorkerVersionRef("researcher", "v0")
            binding, _, job = h.execute_and_grade("opp", "task", worker)
            original = Path(binding.harbor_trial.trial_dir) / "result.json"
            before = original.read_bytes()
            h.regrade(binding, job)
            self.assertEqual(before, original.read_bytes())

    def test_binding_projects_to_graph(self):
        with tempfile.TemporaryDirectory() as td:
            h = FastCampaignHarness(td, FakeWorkerRuntime())
            worker = WorkerVersionRef("researcher", "v0")
            binding, e0, job = h.execute_and_grade("opp", "task", worker)
            e1 = h.regrade(binding, job)
            g = MemoryGraphSink()
            g.project_run_binding(binding)
            g.project_evaluation(e0)
            g.project_evaluation(e1)
            joined = "\n".join(g.queries)
            self.assertIn("WorkerVersion", joined)
            self.assertIn("HarborTrial", joined)
            self.assertIn("AssessorVersion", joined)

    def test_rewardkit_task_is_real_layout(self):
        with tempfile.TemporaryDirectory() as td:
            src = Path(td) / "workspace"; src.mkdir()
            (src / "submission.md").write_text("# Submission\n## Architecture\n## Evidence\nhello")
            out = Path(td) / "task"
            build_artifact_evaluation_task(src, out, AssessorSpec())
            task_toml = (out / "task.toml").read_text()
            self.assertIn('environment_mode = "separate"', task_toml)
            self.assertIn('artifacts = ["/app/workspace"]', task_toml)
            self.assertTrue((out / "tests" / "test.sh").exists())
            self.assertIn("harbor-rewardkit", (out / "tests" / "test.sh").read_text())

    def test_existing_h0_h4_not_replaced(self):
        setup = HumanDependency("human.oauth_consent", recurrence="once")
        steps = [
            ExecutionStep("enter", "oauth", "human", "oauth", setup),
            ExecutionStep("work", "build", "agent", "workspace"),
            ExecutionStep("submit", "submit", "agent", "api"),
        ]
        self.assertEqual("H1", derive_autonomy_level(steps))
        per = HumanDependency("human.subjective_approval", recurrence="per_run")
        steps.append(ExecutionStep("approve", "approve", "human", "browser", per))
        self.assertEqual("H2", derive_autonomy_level(steps))

    def test_automation_prefers_official_surface(self):
        c = [
            AutomationCandidate("human.manual_upload", "browser", "playwright", True, .9),
            AutomationCandidate("human.manual_upload", "official_webmcp", "venue", True, .7),
        ]
        self.assertEqual("official_webmcp", choose_automation(c).method)

    def test_credential_ref_rejects_secretish_value(self):
        CredentialRef("infisical", "roblox-main", ("asset.write",))
        with self.assertRaises(ValueError):
            CredentialRef("env", "sk-secret-looking")

    def test_harbor_commands_match_current_cli_contract(self):
        h = HarborCLI()
        self.assertEqual(["harbor", "run", "-p", "task", "-a", "nop", "--env", "docker"], h.run_command("task"))
        self.assertEqual(["harbor", "job", "regrade", "jobs/x", "-p", "task-v2", "-e", "docker"], h.regrade_command("jobs/x", "task-v2"))


    def test_letta_http_client_contract(self):
        seen = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def _reply(self, obj):
                raw = json.dumps(obj).encode(); self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
            def do_POST(self):
                n = int(self.headers.get("Content-Length", "0")); body = json.loads(self.rfile.read(n) or b"{}")
                seen.append((self.path, body))
                if self.path == "/workers": self._reply({"ok": True, "mapping": {"worker_id": body["worker_id"], "letta_agent_id": "a1"}})
                else: self._reply({"ok": True, "agent_id": "a1", "conversation_id": "c1", "session_id": "s1", "output_content": "done", "duration_ms": 3, "tool_calls": [], "tool_results": []})
        srv = HTTPServer(("127.0.0.1", 0), Handler); t = threading.Thread(target=srv.serve_forever, daemon=True); t.start()
        try:
            c = LettaRuntimeClient(f"http://127.0.0.1:{srv.server_port}")
            c.ensure_worker("researcher", model="m")
            r = c.execute("researcher", "task", "/tmp/work", timeout=4)
            self.assertTrue(r.ok); self.assertEqual("c1", r.conversation_id)
            self.assertEqual("/workers/researcher/run", seen[1][0])
            self.assertEqual("/tmp/work", seen[1][1]["workspace"])
        finally:
            srv.shutdown(); srv.server_close()

    def test_hydra_http_contract(self):
        received = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_POST(self):
                n = int(self.headers.get("Content-Length", "0")); body = json.loads(self.rfile.read(n) or b"{}")
                received.append((self.path, self.headers.get("X-Graph-Namespace"), body))
                raw = b'{"columns":[],"rows":[]}'
                self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
        srv = HTTPServer(("127.0.0.1", 0), Handler); t = threading.Thread(target=srv.serve_forever, daemon=True); t.start()
        try:
            c = HydraHTTPClient(base_url=f"http://127.0.0.1:{srv.server_port}", token="x", namespace="lab", graph="default")
            out = c.query("CREATE (a {id: 1})")
            self.assertEqual([], out["rows"])
            self.assertEqual("/v1/graphs/default/query", received[0][0])
            self.assertEqual("lab", received[0][1])
            self.assertEqual("cell-0", received[0][2]["cell_id"])
        finally:
            srv.shutdown(); srv.server_close()


if __name__ == "__main__":
    unittest.main()
