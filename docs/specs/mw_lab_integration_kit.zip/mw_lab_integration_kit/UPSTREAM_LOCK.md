# Upstream reference lock (research snapshot: 2026-08-31)

This kit does **not vendor** upstream source. It deliberately depends on public boundaries.

- Moltwork branch reviewed: `prx0r/mw@a6229fe7e3f559aa1df5ab3b1a5186040c5c472c` (`ethonline-2026`)
- Harbor main inspected: `harbor-framework/harbor@256a0828eba11ab4a3d88edb9b07ef1c261cbc42`
- Letta Agent SDK: use `@letta-ai/letta-agent-sdk`; local execution requires Node >=22.19.
- HydraDB: integrate over documented HTTP/OpenCypher or Neo4j-compatible Bolt; do not reproduce the database.
- Reward Kit: use `harbor-rewardkit` inside Harbor verifiers.

Docs checked:
- https://www.harborframework.com/docs/getting-started
- https://www.harborframework.com/docs/run-jobs/regrade
- https://www.harborframework.com/docs/run-jobs/results-and-artifacts
- https://www.harborframework.com/docs/rewardkit
- https://www.harborframework.com/docs/agents
- https://github.com/letta-ai/letta-agent-sdk
- https://github.com/hydra-db/hydradb/blob/main/README.md
